Cycle = Class{}

function Cycle:init(cycle)
end
